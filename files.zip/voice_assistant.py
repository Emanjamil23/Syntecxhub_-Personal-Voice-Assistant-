"""
Project 1 - Personal Voice Assistant
Syntecxhub Internship

What this script does:
1. Listens to the microphone (speech-to-text using SpeechRecognition)
2. Matches the command with simple rules (keywords)
3. Does the action (open app, search web, tell time, etc.)
4. Replies with voice (text-to-speech using pyttsx3)

Install:
    pip install SpeechRecognition pyttsx3 pyaudio

Run:
    python voice_assistant.py

Say "help" to hear the sample commands, say "exit" to stop.
If the microphone is not working, the program lets you type commands instead.
"""

import datetime
import os
import random
import subprocess
import urllib.parse
import webbrowser

import pyttsx3
import speech_recognition as sr

# ---------------- text to speech ----------------

try:
    engine = pyttsx3.init()
    engine.setProperty("rate", 170)
except Exception as e:
    engine = None
    print("Text-to-speech could not start:", e)


def speak(text):
    """Print the reply and also say it out loud."""
    print("Assistant:", text)
    if engine is None:
        return
    try:
        engine.say(text)
        engine.runAndWait()
    except Exception as e:
        print("(Could not speak:", e, ")")


# ---------------- speech to text ----------------

recognizer = sr.Recognizer()

try:
    microphone = sr.Microphone()
except Exception as e:
    microphone = None
    print("Microphone not found:", e)
    print("You can type your commands instead.")


def listen():
    """Listen from the mic and return the command as lowercase text.
    Returns an empty string if nothing was understood."""

    # no microphone, so use keyboard
    if microphone is None:
        return input("You (type): ").lower().strip()

    try:
        with microphone as source:
            recognizer.adjust_for_ambient_noise(source, duration=0.5)
            print("Listening...")
            audio = recognizer.listen(source, timeout=5, phrase_time_limit=6)
        text = recognizer.recognize_google(audio)
        print("You said:", text)
        return text.lower().strip()

    except sr.WaitTimeoutError:
        print("No speech heard.")
    except sr.UnknownValueError:
        speak("Sorry, I could not understand that. Please say it again.")
    except sr.RequestError:
        speak("Speech service is not available. Please check your internet.")
    except OSError:
        speak("There is a problem with the microphone.")
    except Exception as e:
        print("Unexpected error:", e)
    return ""


# ---------------- actions ----------------

APPS = {
    "notepad": "notepad",
    "calculator": "calc",
    "paint": "mspaint",
    "command prompt": "cmd",
    "file explorer": "explorer",
}

WEBSITES = {
    "youtube": "https://www.youtube.com",
    "google": "https://www.google.com",
    "github": "https://github.com",
    "gmail": "https://mail.google.com",
    "linkedin": "https://www.linkedin.com",
}

JOKES = [
    "Why do programmers prefer dark mode? Because light attracts bugs.",
    "Why was the computer cold? It left its Windows open.",
    "I told my computer I needed a break, and it said no problem, it will go to sleep.",
]


def tell_time(command):
    now = datetime.datetime.now().strftime("%I:%M %p")
    speak("The time is " + now)


def tell_date(command):
    today = datetime.datetime.now().strftime("%A, %d %B %Y")
    speak("Today is " + today)


def open_something(command):
    # first check websites, then apps
    for name, url in WEBSITES.items():
        if name in command:
            speak("Opening " + name)
            webbrowser.open(url)
            return

    for name, program in APPS.items():
        if name in command:
            speak("Opening " + name)
            try:
                subprocess.Popen(program, shell=True)
            except Exception as e:
                speak("Sorry, I could not open " + name)
                print("Error:", e)
            return

    speak("Sorry, I don't know that app yet.")


def search_web(command):
    # remove the extra words and keep only the search topic
    query = command
    for word in ["search for", "search", "google", "on the web", "on google"]:
        query = query.replace(word, "")
    query = query.strip()

    if query == "":
        speak("What do you want me to search?")
        return

    speak("Searching for " + query)
    url = "https://www.google.com/search?q=" + urllib.parse.quote(query)
    webbrowser.open(url)


def play_on_youtube(command):
    query = command.replace("play", "").replace("on youtube", "").strip()
    if query == "":
        speak("What should I play?")
        return
    speak("Playing " + query + " on YouTube")
    url = "https://www.youtube.com/results?search_query=" + urllib.parse.quote(query)
    webbrowser.open(url)


def greet(command):
    hour = datetime.datetime.now().hour
    if hour < 12:
        speak("Good morning! How can I help you?")
    elif hour < 18:
        speak("Good afternoon! How can I help you?")
    else:
        speak("Good evening! How can I help you?")


def tell_joke(command):
    speak(random.choice(JOKES))


def show_help(command):
    speak("You can say: what is the time, what is the date, open notepad, "
          "open youtube, search python tutorials, play music on youtube, "
          "tell me a joke, or exit.")


# ---------------- rule mapping ----------------
# each rule = (list of keywords, function to run)
# the first rule that matches will run

RULES = [
    (["time"], tell_time),
    (["date", "day today"], tell_date),
    (["open", "launch", "start"], open_something),
    (["play"], play_on_youtube),
    (["search", "google"], search_web),
    (["joke"], tell_joke),
    (["help", "what can you do", "commands"], show_help),
    (["hello", "hi", "hey"], greet),
]

EXIT_WORDS = ["exit", "quit", "stop", "bye", "goodbye"]


def handle_command(command):
    """Find the matching rule and run it. Returns False when we should stop."""
    for word in EXIT_WORDS:
        if word in command:
            speak("Goodbye! Have a nice day.")
            return False

    for keywords, action in RULES:
        for word in keywords:
            if word in command:
                try:
                    action(command)
                except Exception as e:
                    speak("Sorry, something went wrong.")
                    print("Error:", e)
                return True

    speak("Sorry, I don't know that command. Say help to hear what I can do.")
    return True


# ---------------- main ----------------

def main():
    speak("Hello, I am your personal voice assistant. Say help to hear the commands.")
    running = True
    while running:
        try:
            command = listen()
            if command == "":
                continue
            running = handle_command(command)
        except KeyboardInterrupt:
            speak("Goodbye!")
            break


if __name__ == "__main__":
    main()
