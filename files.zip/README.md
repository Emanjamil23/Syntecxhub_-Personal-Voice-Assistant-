# Personal Voice Assistant

**Syntecxhub Internship - Project 1**

A simple Python voice assistant. It listens to your voice, understands a few commands using simple rules, performs the action, and replies with speech.

## Features

- Speech-to-text using the SpeechRecognition library
- Text-to-speech using pyttsx3 (works offline)
- Rule-based command mapping using keywords
- Opens apps and websites, searches the web, tells time and date
- Error handling for no speech, unclear speech, no internet, and missing microphone
- If the microphone is not available, you can type the commands

## Sample Commands

| Say | What happens |
|---|---|
| "hello" | Greets you |
| "what is the time" | Tells the current time |
| "what is the date" | Tells today's date |
| "open notepad" | Opens Notepad |
| "open calculator" | Opens Calculator |
| "open youtube" | Opens YouTube in the browser |
| "search python tutorials" | Searches Google |
| "play music on youtube" | Searches music on YouTube |
| "tell me a joke" | Tells a joke |
| "help" | Tells the list of commands |
| "exit" | Stops the assistant |

## Requirements

- Python 3.8 or newer
- A microphone and internet connection (the speech recognition uses Google's free service)

Install the libraries:

```
pip install -r requirements.txt
```

If `pyaudio` gives an error on Windows, try:

```
pip install pipwin
pipwin install pyaudio
```

## How to Run

```
python voice_assistant.py
```

## How It Works

1. The microphone records your voice.
2. `recognize_google` converts the voice into text.
3. The text is checked against the keyword rules in `RULES`.
4. The matching function runs (open app, search, tell time, etc.).
5. The reply is printed and spoken using pyttsx3.

## Error Handling

- No speech heard: the assistant keeps listening
- Speech not understood: asks you to repeat
- No internet: tells you the speech service is not available
- No microphone: switches to typed input
- Any unexpected error inside a command is caught, so the program does not crash

## Project Files

- `voice_assistant.py` - main script
- `requirements.txt` - libraries needed
- `README.md` - project description

## Author

Eman Jamil
